let phone = document.getElementById('phone');
let tablet = document.getElementById('tablet');
let computer = document.getElementById('computer');
let gadget = document.getElementById('gadget');
let game = document.getElementById('game');
let mi = document.getElementById('mi');
let  slides = document.querySelectorAll('samsoung-item');
let btndown = document.getElementById('btn-down');
let btnup = document.getElementById('btn-up');
let text = document.querySelector('text-hide');
const sliderContainer = document.getElementById('slider-container');
const slidercontainermi = document.getElementById('slider-container-mi');
const slidercontainerapple = document.getElementById('slider-container-apple');
const slidercontaineraccessories = document.getElementById('slider-container-accessories');
const slidercontainerhandsfree = document.getElementById('slider-container-handsfree');
const sslidercontainernewproduct = document.getElementById('slider-container-newproduct');
const slidercontainersuggestedproduct = document.getElementById('slider-container-suggestedproduct');
const slidercontainerbestsel = document.getElementById('slider-container-bestsel');
const arcivenews = document.getElementById('archivenews');
let isDragging = false;
let startPosition = 0;
let startScrollLeft = 0;
let isDraggingmi = false;
let startPositionmi = 0;
let startScrollLeftmi = 0;
let isDraggingapple = false;
let startPositionapple = 0;
let startScrollLeftapple = 0;
let isDraggingaccessories = false;
let startPositionaccessories = 0;
let startScrollLeftaccessories = 0;
let isDraggingnewproduct = false;
let startPositionnewproduct = 0;
let startScrollLeftnewproduct = 0;
let isDraggingsuggestedproduct = false;
let startPositionsuggestedproduct = 0;
let startScrollLeftsuggestedproductt = 0;
let isDraggingbestsel = false;
let startPositionbestsel = 0;
let startScrollLeftbestsel = 0;
let isDraggingarcivenews = false;
let startPositionarcivenews = 0;
let startScrollLeftarcivenews = 0;

$(document).ready(function () {
    $('.header-fix-item').click(function(){
        $('.header-fix-item').each(function(){
            $(this).css('background-color','transparent');
            $(this).css('color','black'); 
            $(this).css('flex-direction','column');
            $(this).css('border-radius','0px');
            $(this).css('margin','0');
            $(this).css('flex','1');
            $(this).css('justify-content','center')
        })
            $(this).css('background-color','#ffebcc');
            $(this).css('color','#f90');
            $(this).css('flex-direction','row');
            $(this).css('border-radius','50px');
            $(this).css('margin','10px 0');
            $(this).css('flex','1.2');
            $(this).css('font-weight','700');
            $(this).css('justify-content','space-around');
    });
})




sliderContainer.addEventListener('mousedown', (e) => {
    isDragging = true;
    startPosition = e.clientX;
    startScrollLeft = sliderContainer.scrollLeft;
});
document.addEventListener('mouseup', () => {
    isDragging = false;
});
document.addEventListener('mousemove', (e) => {
    if (isDragging) {
        const delta = e.clientX - startPosition;
        sliderContainer.scrollLeft = startScrollLeft - delta;
    }
});
slidercontainermi.addEventListener('mousedown', (e) => {
    isDraggingmi = true;
    startPositionmi = e.clientX;
    startScrollLeftmi = slidercontainermi.scrollLeft;
});
document.addEventListener('mouseup', () => {
    isDraggingmi = false;
});
document.addEventListener('mousemove', (e) => {
    if (isDraggingmi) {
        const delta = e.clientX - startPositionmi;
        slidercontainermi.scrollLeft = startScrollLeftmi - delta;
    }
});
slidercontainerapple.addEventListener('mousedown', (e) => {
    isDraggingapple = true;
    startPositionapple = e.clientX;
    startScrollLeftapple = slidercontainerapple.scrollLeft;
});
document.addEventListener('mouseup', () => {
    isDraggingapple = false;
});
document.addEventListener('mousemove', (e) => {
    if (isDraggingapple) {
        const delta = e.clientX - startPositionapple;
        slidercontainerapple.scrollLeft = startScrollLeftapple - delta;
    }
});
slidercontaineraccessories.addEventListener('mousedown', (e) => {
    isDraggingaccessories = true;
    startPositionaccessories = e.clientX;
    startScrollLeftaccessories = slidercontaineraccessories.scrollLeft;
});
document.addEventListener('mouseup', () => {
    isDraggingaccessories = false;
});
document.addEventListener('mousemove', (e) => {
    if (isDraggingaccessories) {
        const delta = e.clientX - startPositionaccessories;
        slidercontaineraccessories.scrollLeft = startScrollLeftaccessories - delta;
    }
});
slidercontainerhandsfree.addEventListener('mousedown', (e) => {
    isDragging = true;
    startPosition = e.clientX;
    startScrollLeft = slidercontainerhandsfree.scrollLeft;
});
document.addEventListener('mouseup', () => {
    isDragging = false;
});
document.addEventListener('mousemove', (e) => {
    if (isDragging) {
        const delta = e.clientX - startPosition;
        slidercontainerhandsfree.scrollLeft = startScrollLeft - delta;
    }
});
sslidercontainernewproduct.addEventListener('mousedown', (e) => {
    isDraggingnewproduct = true;
    startPositionnewproduct = e.clientX;
    startScrollLeftnewproduct = sslidercontainernewproduct.scrollLeft;
});
document.addEventListener('mouseup', () => {
    isDraggingnewproduct = false;
});
document.addEventListener('mousemove', (e) => {
    if (isDraggingnewproduct) {
        const delta = e.clientX - startPositionnewproduct;
        sslidercontainernewproduct.scrollLeft = startScrollLeftnewproduct - delta;
    }
});
slidercontainersuggestedproduct.addEventListener('mousedown', (e) => {
    isDraggingsuggestedproduct = true;
    startPositionsuggestedproduct = e.clientX;
    startScrollLeftsuggestedproductt = slidercontainersuggestedproduct.scrollLeft;
});
document.addEventListener('mouseup', () => {
    isDraggingsuggestedproduct = false;
});
document.addEventListener('mousemove', (e) => {
    if (isDraggingsuggestedproduct) {
        const delta = e.clientX - startPositionsuggestedproduct;
        slidercontainersuggestedproduct.scrollLeft = startScrollLeftsuggestedproductt - delta;
    }
});
slidercontainerbestsel.addEventListener('mousedown', (e) => {
    isDraggingbestsel = true;
    startPositionbestsel = e.clientX;
    startScrollLeftbestsel = slidercontainerbestsel.scrollLeft;
});
document.addEventListener('mouseup', () => {
    isDraggingbestsel = false;
});
document.addEventListener('mousemove', (e) => {
    if (isDraggingbestsel) {
        const delta = e.clientX - startPositionbestsel;
        slidercontainerbestsel.scrollLeft = startScrollLeftbestsel - delta;
    }
});
arcivenews.addEventListener('mousedown', (e) => {
    isDraggingarcivenews = true;
    startPositionarcivenews = e.clientX;
    startScrollLeftarcivenews = arcivenews.scrollLeft;
});
document.addEventListener('mouseup', () => {
    isDraggingarcivenews = false;
});
document.addEventListener('mousemove', (e) => {
    if (isDraggingarcivenews) {
        const delta = e.clientX - startPositionarcivenews;
        arcivenews.scrollLeft = startScrollLeftarcivenews - delta;
    }
});






document.addEventListener('DOMContentLoaded', function () {
    const slider = document.getElementById('slider');
    const slides = document.querySelectorAll('.slide');
    const totalSlides = slides.length;
    let currentSlide = 0;

    function showSlide(index) {
        slides.forEach((slide, i) => {
            if (i === index) {
                slide.style.display = 'block';
            } else {
                slide.style.display = 'none';
            }
        });
    }

    function nextSlide() {
        currentSlide = (currentSlide + 1) % totalSlides;
        showSlide(currentSlide);
    }

    function prevSlide() {
        currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
        showSlide(currentSlide);
    }

    function autoSlide() {
        nextSlide();
    }

    // Set up automatic sliding every 3 seconds (adjust the interval as needed)
    const intervalId = setInterval(autoSlide, 3000);

    // Stop automatic sliding on button click
    const btnLeft = document.querySelector('.btn-left');
    const btnRight = document.querySelector('.btn-right');

    btnLeft.addEventListener('click', function () {
        clearInterval(intervalId);
        prevSlide();
    });

    btnRight.addEventListener('click', function () {
        clearInterval(intervalId);
        nextSlide();
    });

    // Initial slide display
    showSlide(currentSlide);
});



phone.addEventListener('mousemove', () => OpenPage(event, 'phoneitem'));
tablet.addEventListener('mousemove', () => OpenPage(event, 'tabletitem'));
computer.addEventListener('mousemove', () => OpenPage(event, 'computeritem'));
gadget.addEventListener('mousemove', () => OpenPage(event, 'gadgetitem'));
game.addEventListener('mousemove', () => OpenPage(event, 'gameitem'));
mi.addEventListener('mousemove', () => OpenPage(event, 'miitem'));
btnup.addEventListener('click', () => hide(event,'text-hide'));
btndown.addEventListener('click', () => Open(event,'text-hide'));
function OpenPage(event, pagename) {
    let i, headersubmenu;
    headersubmenu = document.getElementsByClassName('header-submenu-left-item');
    for (i = 0; i < headersubmenu.length; i++) {
        headersubmenu[i].style.display = 'none';
    }
    document.getElementById(pagename).style.display = 'block';
}
function hide(event, pagename) {

    let i, tabContents, tabLinks;
    tabContents = document.getElementsByClassName('text-hide');
    tabBtn = document.getElementById('btn-up');
    tabbtndown= document.getElementById('btn-down');
    tabbtndown.style.display='block';
    tabBtn.style.display='none';
    for (i = 0; i < tabContents.length; i++) {
        tabContents[i].style.display = 'none';
    }

    

    document.getElementById(pagename).style.display = 'block';
}
function Open(event, pagename) {

    let i, tabContents, tabLinks;
    tabContents = document.getElementsByClassName('text-hide');
    tabBtn = document.getElementById('btn-up');
    tabbtndown= document.getElementById('btn-down');
    tabbtndown.style.display='none';
    tabBtn.style.display='block';
    for (i = 0; i < tabContents.length; i++) {
        tabContents[i].style.display = 'block';
    }
   

}
function prev(){
    document.getElementById('slider-container').scrollLeft -= 270;
}
function next()
{
    document.getElementById('slider-container').scrollLeft += 270;
}
function prevmi(){
    document.getElementById('slider-container-mi').scrollLeft -= 270;

}
function nextmi()
{
    document.getElementById('slider-container-mi').scrollLeft += 270;

}
function prevapple(){
    document.getElementById('slider-container-apple').scrollLeft -= 270;

}
function nextapple()
{
    document.getElementById('slider-container-apple').scrollLeft += 270;

}
function prevaccessories(){
    document.getElementById('slider-container-accessories').scrollLeft -= 270;

}
function nextaccessories()
{
    document.getElementById('slider-container-accessories').scrollLeft += 270;

}
function prevhandsfree(){
    document.getElementById('slider-container-handsfree').scrollLeft -= 270;

}
function nexthandsfree()
{
    document.getElementById('sslider-container-handsfree').scrollLeft += 270;

}
function prevnewproduct(){
    document.getElementById('slider-container-newproduct').scrollLeft -= 270;

}
function nextnewproduct()
{
    document.getElementById('slider-container-newproduct').scrollLeft += 270;

}
function prevsuggestedproduct(){
    document.getElementById('slider-container-suggestedproduct').scrollLeft -= 270;

}
function nextsuggestedproduct()
{
    document.getElementById('slider-container-suggestedproduct').scrollLeft += 270;

}
function prevbestsel(){
    document.getElementById('slider-container-bestsel').scrollLeft -= 270;

}
function nextbestsel()
{
    document.getElementById('slider-container-bestsel').scrollLeft += 270;

}
function prevarchivenews(){
    document.getElementById('archivenews').scrollLeft -= 270;

}
function nextarchivenews()
{
    document.getElementById('archivenews').scrollLeft += 270;

}
$(".slide img").on("click" , function(){
$(this).toggleClass('zoomed');
$(".overlay").toggleClass('active');
})

let touch = document.getElementsByClassName('slider');

touch.addEventListener('touchmove',function(){

});
let acrchive = document.getElementById('archivenews');
acrchive.addEventListener('touchmove',function(){

});



